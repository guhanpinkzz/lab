// utils/yearNormalizer.js - Centralized Year Format Management
// ✅ FIXED: Unified year format handling across the entire project

/**
 * Standard year formats used in the system:
 * Database: "2", "3", "4" (string numbers)
 * Display: "2nd Year", "3rd Year", "4th Year" (human readable)
 * API: "2", "3", "4" (for backend compatibility)
 */

// Valid year mappings
const YEAR_MAPPINGS = {
  // Numbers (string and numeric)
  '1': { db: '1', display: '1st Year', short: '1st' },
  '2': { db: '2', display: '2nd Year', short: '2nd' },
  '3': { db: '3', display: '3rd Year', short: '3rd' },
  '4': { db: '4', display: '4th Year', short: '4th' },
  1: { db: '1', display: '1st Year', short: '1st' },
  2: { db: '2', display: '2nd Year', short: '2nd' },
  3: { db: '3', display: '3rd Year', short: '3rd' },
  4: { db: '4', display: '4th Year', short: '4th' },
  
  // Ordinal formats
  '1st': { db: '1', display: '1st Year', short: '1st' },
  '2nd': { db: '2', display: '2nd Year', short: '2nd' },
  '3rd': { db: '3', display: '3rd Year', short: '3rd' },
  '4th': { db: '4', display: '4th Year', short: '4th' },
  
  // Year formats
  '1st year': { db: '1', display: '1st Year', short: '1st' },
  '2nd year': { db: '2', display: '2nd Year', short: '2nd' },
  '3rd year': { db: '3', display: '3rd Year', short: '3rd' },
  '4th year': { db: '4', display: '4th Year', short: '4th' },
  
  // Word formats
  'first': { db: '1', display: '1st Year', short: '1st' },
  'second': { db: '2', display: '2nd Year', short: '2nd' },
  'third': { db: '3', display: '3rd Year', short: '3rd' },
  'fourth': { db: '4', display: '4th Year', short: '4th' },
};

/**
 * Normalize year input to database format
 * @param {string|number} year - Year in any supported format
 * @returns {string|null} - Normalized year for database ("1", "2", "3", "4") or null if invalid
 */
export function normalizeYearForDB(year) {
  if (!year) return null;
  
  const normalized = year.toString().toLowerCase().trim();
  const mapping = YEAR_MAPPINGS[normalized];
  
  return mapping ? mapping.db : null;
}

/**
 * Convert year to display format
 * @param {string|number} year - Year in any supported format
 * @returns {string} - Display format ("1st Year", "2nd Year", etc.) or "Unknown Year"
 */
export function normalizeYearForDisplay(year) {
  if (!year) return 'Unknown Year';
  
  const normalized = year.toString().toLowerCase().trim();
  const mapping = YEAR_MAPPINGS[normalized];
  
  return mapping ? mapping.display : `${year} (Unknown)`;
}

/**
 * Convert year to short format
 * @param {string|number} year - Year in any supported format  
 * @returns {string} - Short format ("1st", "2nd", etc.) or "Unknown"
 */
export function normalizeYearForShort(year) {
  if (!year) return 'Unknown';
  
  const normalized = year.toString().toLowerCase().trim();
  const mapping = YEAR_MAPPINGS[normalized];
  
  return mapping ? mapping.short : year.toString();
}

/**
 * Get all valid years in specified format
 * @param {string} format - 'db', 'display', or 'short'
 * @returns {Array<string>} - Array of years in specified format
 */
export function getAllYears(format = 'display') {
  const years = ['1', '2', '3', '4'];
  return years.map(year => {
    switch (format) {
      case 'db': return YEAR_MAPPINGS[year].db;
      case 'short': return YEAR_MAPPINGS[year].short;
      case 'display':
      default: return YEAR_MAPPINGS[year].display;
    }
  });
}

/**
 * Validate if year is supported
 * @param {string|number} year - Year to validate
 * @returns {boolean} - True if year is valid
 */
export function isValidYear(year) {
  if (!year) return false;
  const normalized = year.toString().toLowerCase().trim();
  return YEAR_MAPPINGS.hasOwnProperty(normalized);
}

/**
 * Bulk normalize years for database operations
 * @param {Array} years - Array of years in any format
 * @returns {Array<string>} - Array of normalized years (invalid ones filtered out)
 */
export function bulkNormalizeYears(years) {
  if (!Array.isArray(years)) return [];
  
  return years
    .map(normalizeYearForDB)
    .filter(year => year !== null);
}

/**
 * Create year filter for database queries
 * @param {string|number} year - Year to filter by
 * @returns {Object|null} - Prisma where clause or null if invalid year
 */
export function createYearFilter(year) {
  const normalizedYear = normalizeYearForDB(year);
  return normalizedYear ? { year: normalizedYear } : null;
}

// Export constants for direct use
export const VALID_YEARS_DB = ['1', '2', '3', '4'];
export const VALID_YEARS_DISPLAY = ['1st Year', '2nd Year', '3rd Year', '4th Year'];
export const VALID_YEARS_SHORT = ['1st', '2nd', '3rd', '4th'];

// Default export with all functions
export default {
  normalizeYearForDB,
  normalizeYearForDisplay,
  normalizeYearForShort,
  getAllYears,
  isValidYear,
  bulkNormalizeYears,
  createYearFilter,
  VALID_YEARS_DB,
  VALID_YEARS_DISPLAY,
  VALID_YEARS_SHORT
};