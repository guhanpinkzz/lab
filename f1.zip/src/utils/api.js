// CORRECTED API Utility with Fixed Lab Subject Management Functions
const BASE = process.env.REACT_APP_API || 'http://localhost:4000';

function _headers(token) {
  return {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
}

async function _req(path, { method = 'GET', token, body } = {}) {
  const url = `${BASE}${path}`;
  
  console.log(`🌐 API Request: ${method} ${url}`);
  console.log(`🌐 BASE URL: ${BASE}`);
  if (body) console.log(`📤 Request body:`, body);
  if (token) console.log(`🔑 Token present: ${token.substring(0, 20)}...`);
  
  try {
    const res = await fetch(url, {
      method,
      headers: _headers(token),
      body: body ? JSON.stringify(body) : undefined,
      mode: 'cors',
      credentials: 'include'
    });
    
    console.log(`📡 Response status: ${res.status} ${res.statusText}`);
    
    let json;
    try {
      json = await res.json();
    } catch (jsonError) {
      console.error(`❌ JSON parsing failed:`, jsonError);
      json = { error: 'Invalid JSON response from server' };
    }
    
    if (!res.ok) {
      console.error(`❌ API Error Response:`, json);
      throw json;
    }
    
    console.log(`✅ API Success Response:`, json);
    return json;
    
  } catch (fetchError) {
    console.error(`❌ Network/Fetch Error:`, fetchError);
    console.error(`❌ Error name: ${fetchError.name}`);
    console.error(`❌ Error message: ${fetchError.message}`);
    
    // More specific error handling
    if (fetchError.name === 'TypeError' && fetchError.message.includes('Failed to fetch')) {
      throw { 
        error: 'Cannot connect to backend server. Please check if the server is running on port 4000.',
        details: 'Connection failed - backend server may be down or unreachable.'
      };
    }
    
    if (fetchError.message && fetchError.message.includes('CORS')) {
      throw { 
        error: 'CORS error - backend server CORS configuration issue.',
        details: 'Cross-origin request blocked. Check backend CORS settings.'
      };
    }
    
    if (fetchError.message && fetchError.message.includes('NetworkError')) {
      throw { 
        error: 'Network error. Check your internet connection and backend server.',
        details: 'Network connectivity issue detected.'
      };
    }
    
    // For debugging: throw the original error instead of masking it
    throw fetchError.error ? fetchError : { 
      error: `Connection failed: ${fetchError.message || 'Unknown error'}`,
      details: fetchError.message || 'An unexpected error occurred',
      originalError: fetchError.message,
      errorType: fetchError.name
    };
  }
}

/* Authentication */
export function login(username, password, role) {
  console.log(`🔐 Attempting login: ${username} as ${role}`);
  return _req('/auth/login', { method: 'POST', body: { username, password, role } });
}

export function signupHOD(payload, token) {
  return _req('/auth/signup-hod', { method: 'POST', token, body: payload });
}

export function changePassword({ currentPassword, newPassword }, token) {
  return _req('/auth/change-password', { method: 'POST', token, body: { currentPassword, newPassword } });
}

export function resetPassword({ newPassword }, token) {
  return _req('/auth/reset-password', { method: 'POST', token, body: { newPassword } });
}

/* Users - Enhanced with debugging */
export function fetchUsers(token, query = {}) {
  console.log(`👥 Fetching users with query:`, query);
  const q = Object.keys(query).length ? `?${new URLSearchParams(query).toString()}` : '';
  return _req(`/users${q}`, { token });
}

export function createUser(payload, token) {
  console.log(`➕ Creating user:`, payload);
  return _req('/users', { method: 'POST', token, body: payload });
}

export function deleteUser(userId, token) {
  return _req(`/users/${encodeURIComponent(userId)}`, { method: 'DELETE', token });
}

export function setUserPassword(userId, newPassword, token) {
  return _req(`/users/${encodeURIComponent(userId)}/password`, { method: 'PATCH', token, body: { newPassword } });
}

export function assignStudentLabs(studentId, labs, token) {
  return _req(`/users/students/${encodeURIComponent(studentId)}/labs`, { method: 'PUT', token, body: { labs } });
}

/* Debug Functions */
export function debugGetAllUsers(token) {
  console.log(`🔍 DEBUG: Getting all users from database`);
  return _req('/users/debug/all', { token });
}

export function testBackendConnection() {
  console.log(`🏥 Testing backend health`);
  return _req('/health', {});
}

/* Labs & Subjects - CORRECTED */
export function listLabs(token) {
  return _req('/labs', { token });
}

export function getYearSubjects(year, token) {
  return _req(`/labs/years/${encodeURIComponent(year)}`, { token });
}

export function setYearSubjects(year, subjects, token) {
  return _req(`/labs/years/${encodeURIComponent(year)}`, { method: 'PUT', token, body: { subjects } });
}

/* Attendance (General) */
export function submitAttendance(payload, token) {
  return _req('/attendance', { method: 'POST', token, body: payload });
}

export function fetchStudentAttendance(studentId, token) {
  return _req(`/attendance/student/${encodeURIComponent(studentId)}`, { token });
}

export function fetchSummary(token) {
  return _req('/attendance/summary', { token });
}

// Staff Endpoints (keeping existing ones)
export function getStaffDashboard(token) {
  return _req('/staff/dashboard', { token });
}

export function getStaffLabs(token) {
  return _req('/staff/labs', { token });
}

export function getStaffStudents(token, labId = null) {
  const endpoint = labId ? `/staff/students/${labId}` : '/staff/students';
  return _req(endpoint, { token });
}

export function getStaffAttendance(token, labId = null) {
  const endpoint = labId ? `/staff/attendance/${labId}` : '/staff/attendance';
  return _req(endpoint, { token });
}

export function markStaffAttendance(attendanceData, token) {
  return _req('/staff/attendance', { method: 'POST', token, body: attendanceData });
}

export function markBulkStaffAttendance(bulkData, token) {
  return _req('/staff/bulk-attendance', { method: 'POST', token, body: bulkData });
}

export function updateStaffAttendance(attendanceId, updateData, token) {
  return _req(`/staff/attendance/${attendanceId}`, { method: 'PUT', token, body: updateData });
}

export function deleteStaffAttendance(attendanceId, token) {
  return _req(`/staff/attendance/${attendanceId}`, { method: 'DELETE', token });
}

export function getStaffStats(token) {
  return _req('/staff/stats', { token });
}

// **CORRECTED: Lab Subject Management Functions**

// Create new lab subject
export function addLabSubject(labName, year, token) {
  console.log(`➕ Adding lab subject: ${labName} for ${year}`);
  
  // Enhanced validation
  if (!labName || !year) {
    throw { error: 'Lab name and year are required' };
  }
  
  const cleanLabName = labName.toString().trim();
  const cleanYear = year.toString().trim();
  
  if (cleanLabName.length === 0) {
    throw { error: 'Lab name cannot be empty' };
  }
  
  if (cleanLabName.length > 100) {
    throw { error: 'Lab name is too long (maximum 100 characters)' };
  }
  
  const validYears = ['2nd Year', '3rd Year', '4th Year'];
  if (!validYears.includes(cleanYear)) {
    throw { error: `Invalid year format. Must be one of: ${validYears.join(', ')}` };
  }
  
  return _req('/labs', { 
    method: 'POST', 
    token, 
    body: { name: cleanLabName, year: cleanYear } 
  });
}

// Delete lab subject by name and year
export function removeLabSubject(labName, year, token) {
  console.log(`🗑️ Removing lab subject: ${labName} for ${year}`);
  
  // Enhanced validation
  if (!labName || !year) {
    throw { error: 'Lab name and year are required' };
  }
  
  const cleanLabName = labName.toString().trim();
  const cleanYear = year.toString().trim();
  
  if (cleanLabName.length === 0) {
    throw { error: 'Lab name cannot be empty' };
  }
  
  const validYears = ['2nd Year', '3rd Year', '4th Year'];
  if (!validYears.includes(cleanYear)) {
    throw { error: `Invalid year format. Must be one of: ${validYears.join(', ')}` };
  }
  
  return _req('/labs/by-name-year', { 
    method: 'DELETE', 
    token, 
    body: { name: cleanLabName, year: cleanYear } 
  });
}

// Bulk assign students to multiple labs by year
export function bulkAssignStudentsByYear(year, labNames, token) {
  console.log(`🎯 API: Bulk assigning ${labNames?.length || 0} labs to ${year} students:`, labNames);
  
  // Enhanced validation
  if (!year || !labNames) {
    throw { error: 'Year and lab names are required' };
  }
  
  if (!Array.isArray(labNames)) {
    throw { error: 'Lab names must be an array' };
  }
  
  const cleanYear = year.toString().trim();
  const cleanLabNames = labNames
    .map(name => name ? name.toString().trim() : '')
    .filter(name => name.length > 0);
  
  if (cleanLabNames.length === 0) {
    throw { error: 'At least one valid lab name is required' };
  }
  
  const validYears = ['2nd Year', '3rd Year', '4th Year'];
  if (!validYears.includes(cleanYear)) {
    throw { error: `Invalid year format. Must be one of: ${validYears.join(', ')}` };
  }
  
  return _req('/labs/bulk-assign', { 
    method: 'POST', 
    token, 
    body: { year: cleanYear, labNames: cleanLabNames } 
  });
}

// HOD Lab Management
export function createLab(labData, token) {
  console.log(`🏗️ Creating lab:`, labData);
  
  if (!labData || !labData.name || !labData.year) {
    throw { error: 'Lab name and year are required' };
  }
  
  return _req('/labs', { method: 'POST', token, body: labData });
}

export function updateLab(labId, labData, token) {
  console.log(`✏️ Updating lab ${labId}:`, labData);
  
  if (!labId || isNaN(parseInt(labId))) {
    throw { error: 'Valid lab ID is required' };
  }
  
  if (!labData || !labData.name || !labData.year) {
    throw { error: 'Lab name and year are required' };
  }
  
  return _req(`/labs/${labId}`, { method: 'PUT', token, body: labData });
}

export function deleteLab(labId, token) {
  console.log(`🗑️ Deleting lab ${labId}`);
  
  if (!labId || isNaN(parseInt(labId))) {
    throw { error: 'Valid lab ID is required' };
  }
  
  return _req(`/labs/${labId}`, { method: 'DELETE', token });
}

export function assignStaffToLabs(staffId, labIds, token) {
  console.log(`👨‍🏫 Assigning staff ${staffId} to labs:`, labIds);
  
  if (!staffId || isNaN(parseInt(staffId))) {
    throw { error: 'Valid staff ID is required' };
  }
  
  if (!Array.isArray(labIds) || labIds.length === 0) {
    throw { error: 'Lab IDs array is required' };
  }
  
  const cleanLabIds = labIds.filter(id => !isNaN(parseInt(id)));
  if (cleanLabIds.length === 0) {
    throw { error: 'At least one valid lab ID is required' };
  }
  
  return _req('/labs/assign-staff', { 
    method: 'POST', 
    token, 
    body: { staffId: parseInt(staffId), labIds: cleanLabIds.map(id => parseInt(id)) } 
  });
}

export function assignStudentsToLab(labId, studentIds, token) {
  console.log(`👨‍🎓 Assigning students to lab ${labId}:`, studentIds);
  
  if (!labId || isNaN(parseInt(labId))) {
    throw { error: 'Valid lab ID is required' };
  }
  
  if (!Array.isArray(studentIds) || studentIds.length === 0) {
    throw { error: 'Student IDs array is required' };
  }
  
  const cleanStudentIds = studentIds.filter(id => !isNaN(parseInt(id)));
  if (cleanStudentIds.length === 0) {
    throw { error: 'At least one valid student ID is required' };
  }
  
  return _req('/labs/assign-students', { 
    method: 'POST', 
    token, 
    body: { labId: parseInt(labId), studentIds: cleanStudentIds.map(id => parseInt(id)) } 
  });
}

export function getLabAssignmentReport(token) {
  console.log(`📊 Getting lab assignment report`);
  return _req('/labs/report', { token });
}

// Generic HTTP Methods
export function get(path, token) {
  return _req(path, { method: 'GET', token });
}

export function post(path, body, token) {
  console.log(`📤 POST ${path}:`, body);
  return _req(path, { method: 'POST', token, body });
}

export function put(path, body, token) {
  console.log(`📤 PUT ${path}:`, body);
  return _req(path, { method: 'PUT', token, body });
}

export function patch(path, body, token) {
  console.log(`📤 PATCH ${path}:`, body);
  return _req(path, { method: 'PATCH', token, body });
}

export function deleteRequest(path, token) {
  console.log(`🗑️ DELETE ${path}`);
  return _req(path, { method: 'DELETE', token });
}

// Default export with all functions
export default {
  // Authentication
  login,
  signupHOD,
  changePassword,
  resetPassword,
  
  // Users
  fetchUsers,
  createUser,
  deleteUser,
  setUserPassword,
  assignStudentLabs,
  
  // Debug functions
  debugGetAllUsers,
  testBackendConnection,
  
  // Labs & Subjects - CORRECTED
  listLabs,
  getYearSubjects,
  setYearSubjects,
  addLabSubject,
  removeLabSubject,
  bulkAssignStudentsByYear,
  
  // General Attendance
  submitAttendance,
  fetchStudentAttendance,
  fetchSummary,
  
  // Staff Functions
  getStaffDashboard,
  getStaffLabs,
  getStaffStudents,
  getStaffAttendance,
  markStaffAttendance,
  markBulkStaffAttendance,
  updateStaffAttendance,
  deleteStaffAttendance,
  getStaffStats,
  
  // HOD Lab Management - CORRECTED
  createLab,
  updateLab,
  deleteLab,
  assignStaffToLabs,
  assignStudentsToLab,
  getLabAssignmentReport,
  
  // Generic HTTP methods
  get,
  post,
  put,
  patch,
  delete: deleteRequest,
};