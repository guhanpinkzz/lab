// ✅ Corrected App.js — Standardized API Calls with Consistent Error Handling
import React, { useState, useEffect } from "react";
import LoginPage from "./components/LoginPage";
import SignupPage from "./components/SignupPage";
import ResetPasswordPage from "./components/ResetPasswordPage";
import HODDashboard from "./components/HODDashboard";
import StaffDashboard from "./components/StaffDashboard";
import StudentDashboard from "./components/StudentDashboard";
import "./styles/dashboard.css";
import api from './utils/api';
import { saveAuth, getToken, getUser, clearAuth } from './utils/auth';

const App = () => {
  // Global State
  const [currentUser, setCurrentUser] = useState(null);
  const [currentPage, setCurrentPage] = useState("login");
  const [users, setUsers] = useState([]);
  const [attendance, setAttendance] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [labs, setLabs] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // ✅ FIXED: Standardized data loading with proper error handling
  const loadInitialData = async (token, user) => {
    setLoading(true);
    setError(null);
    
    try {
      // Load users (HOD/STAFF only)
      if (user.role === 'HOD' || user.role === 'STAFF') {
        try {
          const usersRes = await api.fetchUsers(token);
          setUsers(Array.isArray(usersRes) ? usersRes : usersRes.users || []);
        } catch (e) { 
          console.warn('fetchUsers failed:', e);
          setError('Failed to load users');
        }
      }

      // Load labs
      try {
        const labsRes = await api.listLabs(token);
        setLabs(Array.isArray(labsRes) ? labsRes : labsRes.labs || []);
      } catch (e) { 
        console.warn('listLabs failed:', e);
      }

      // Load attendance for students
      if (user.role === 'STUDENT' && user.studentId) {
        try {
          const attendanceRes = await api.fetchStudentAttendance(user.studentId, token);
          setAttendance(attendanceRes.attendance || attendanceRes || []);
        } catch (e) { 
          console.warn('fetchStudentAttendance failed:', e);
        }
      }

      // Load attendance summary for HOD
      if (user.role === 'HOD') {
        try {
          const summaryRes = await api.fetchSummary(token);
          setAttendance(summaryRes.attendance || summaryRes || []);
        } catch (e) {
          console.warn('fetchSummary failed:', e);
        }
      }

    } catch (globalError) {
      console.error('Global data loading error:', globalError);
      setError('Failed to load initial data');
    } finally {
      setLoading(false);
    }
  };

  // ✅ Load data after login
  useEffect(() => {
    const token = getToken();
    const user = getUser();
    if (token && user) {
      setCurrentUser(user);
      loadInitialData(token, user);
    }
  }, []);

  // ✅ Notifications: check attendance below 75%
  useEffect(() => {
    const lowAttendanceNotifications = users
      .filter((user) => user.role === "STUDENT")
      .map((student) => {
        const studentAttendance = attendance.filter(
          (a) => a.student_id === student.student_id
        );
        const avgAttendance =
          studentAttendance.length > 0
            ? studentAttendance.reduce((sum, a) => sum + a.percentage, 0) /
              studentAttendance.length
            : 0;

        if (avgAttendance < 75) {
          return {
            id: student.id,
            message: `${student.name}'s attendance is below 75% (${avgAttendance.toFixed(1)}%)`,
            type: "warning",
          };
        }
        return null;
      })
      .filter(Boolean);

    setNotifications(lowAttendanceNotifications);
  }, [attendance, users]);

  // ✅ FIXED: Standardized login with api utility
  const handleLogin = async (username, password, role) => {
    try {
      setLoading(true);
      setError(null);
      
      const res = await api.login(username, password, role.toUpperCase());
      saveAuth(res.token, res.user);
      setCurrentUser(res.user);

      // Load initial data after successful login
      await loadInitialData(res.token, res.user);

      // Navigate based on user state
      if (res.user.temporaryPassword) {
        setCurrentPage('resetPassword');
      } else {
        const dashboardMap = {
          'HOD': 'hodDashboard',
          'STAFF': 'staffDashboard',
          'STUDENT': 'studentDashboard'
        };
        setCurrentPage(dashboardMap[res.user.role] || 'login');
      }
      
      return true;
    } catch (err) {
      console.error('Login error:', err);
      setError(err?.error || err?.message || 'Login failed');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // ✅ FIXED: Standardized signup with api utility
  const handleSignup = async (userData) => {
    try {
      setLoading(true);
      setError(null);
      
      const token = getToken(); // For creating additional HODs
      await api.signupHOD(userData, token);
      
      alert("Signup successful! Please log in.");
      setCurrentPage("login");
    } catch (err) {
      console.error('Signup error:', err);
      const errorMessage = err?.error || err?.message || "Signup failed";
      setError(errorMessage);
      alert(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  // ✅ FIXED: Standardized password reset with api utility
  const handleResetPassword = async ({ currentPassword, newPassword }) => {
    try {
      setLoading(true);
      setError(null);
      
      const token = getToken();
      const user = getUser();
      if (!token) throw new Error('Not authenticated');

      if (user?.temporaryPassword) {
        // First-login reset
        await api.resetPassword({ newPassword }, token);
        // Update user state to clear temporary flag
        const updatedUser = { ...user, temporaryPassword: false };
        saveAuth(token, updatedUser);
        setCurrentUser(updatedUser);
        
        const dashboardMap = {
          'HOD': 'hodDashboard',
          'STAFF': 'staffDashboard', 
          'STUDENT': 'studentDashboard'
        };
        setCurrentPage(dashboardMap[updatedUser.role] || 'login');
      } else {
        // Normal password change
        await api.changePassword({ currentPassword, newPassword }, token);
        alert('Password changed successfully');
      }
    } catch (err) {
      console.error('Reset password error:', err);
      const errorMessage = err?.error || err?.message || 'Password reset failed';
      setError(errorMessage);
      alert(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  // ✅ FIXED: Standardized logout
  const handleLogout = () => {
    clearAuth();
    setCurrentUser(null);
    setUsers([]);
    setAttendance([]);
    setNotifications([]);
    setLabs([]);
    setError(null);
    setCurrentPage("login");
  };

  // ✅ FIXED: Standardized user management with api utility
  const addUser = async (userData) => {
    try {
      setLoading(true);
      setError(null);
      
      const token = getToken();
      const result = await api.createUser(userData, token);
      
      // Refresh user list
      const usersRes = await api.fetchUsers(token);
      setUsers(Array.isArray(usersRes) ? usersRes : usersRes.users || []);
      
      return result.tempPassword || 'User created successfully';
    } catch (err) {
      console.error('Add user error:', err);
      const errorMessage = err?.error || err?.message || 'Failed to add user';
      setError(errorMessage);
      alert(errorMessage);
      return null;
    } finally {
      setLoading(false);
    }
  };

  const deleteUser = async (userId) => {
    try {
      setLoading(true);
      setError(null);
      
      const token = getToken();
      await api.deleteUser(userId, token);
      
      // Update local state
      setUsers(users.filter((u) => u.id !== userId));
    } catch (err) {
      console.error('Delete user error:', err);
      const errorMessage = err?.error || err?.message || 'Delete failed';
      setError(errorMessage);
      alert(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const updateUserPassword = async (userId, newPassword) => {
    try {
      setLoading(true);
      setError(null);
      
      const token = getToken();
      await api.setUserPassword(userId, newPassword, token);
      
      alert('Password updated successfully');
    } catch (err) {
      console.error('Update password error:', err);
      const errorMessage = err?.error || err?.message || 'Password update failed';
      setError(errorMessage);
      alert(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  // ✅ FIXED: Standardized attendance marking with api utility
  const markAttendance = async (attendanceData) => {
    try {
      setLoading(true);
      setError(null);
      
      const token = getToken();
      
      // Submit attendance using standardized API
      for (const record of attendanceData) {
        await api.submitAttendance(record, token);
      }
      
      // Refresh attendance data
      if (currentUser?.role === 'STUDENT' && currentUser.studentId) {
        const attendanceRes = await api.fetchStudentAttendance(currentUser.studentId, token);
        setAttendance(attendanceRes.attendance || attendanceRes || []);
      } else if (currentUser?.role === 'HOD') {
        const summaryRes = await api.fetchSummary(token);
        setAttendance(summaryRes.attendance || summaryRes || []);
      }
      
    } catch (err) {
      console.error('Mark attendance error:', err);
      const errorMessage = err?.error || err?.message || 'Failed to mark attendance';
      setError(errorMessage);
      alert(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  // ✅ Navigation
  const navigateTo = (page) => {
    setError(null); // Clear errors when navigating
    setCurrentPage(page);
  };

  // ✅ Shared Props for all components
  const sharedProps = {
    currentUser,
    users,
    setUsers,
    attendance,
    setAttendance,
    notifications,
    labs,
    loading,
    error,
    handleLogin,
    handleSignup,
    handleResetPassword,
    handleLogout,
    addUser,
    deleteUser,
    updateUserPassword,
    markAttendance,
    navigateTo,
  };

  // ✅ Render current page
  const renderCurrentPage = () => {
    // Show loading overlay if needed
    if (loading && currentPage === 'login') {
      return (
        <div className="loading-overlay">
          <div className="loading-spinner">Loading...</div>
        </div>
      );
    }

    switch (currentPage) {
      case "login":
        return <LoginPage {...sharedProps} />;
      case "signup":
        return <SignupPage {...sharedProps} />;
      case "resetPassword":
        return <ResetPasswordPage {...sharedProps} />;
      case "hodDashboard":
        return <HODDashboard {...sharedProps} />;
      case "staffDashboard":
        return <StaffDashboard {...sharedProps} />;
      case "studentDashboard":
        return <StudentDashboard {...sharedProps} />;
      default:
        return <LoginPage {...sharedProps} />;
    }
  };

  return (
    <div className="app">
      {renderCurrentPage()}
    </div>
  );
};

export default App;