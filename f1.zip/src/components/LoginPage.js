import React, { useState } from 'react';
import { FaUser, FaLock, FaEye, FaEyeSlash } from 'react-icons/fa';
import api from '../utils/api';          // ✅ import API helper
import { saveAuth } from '../utils/auth'; // ✅ if you use saveAuth here




const LoginPage = ({ handleLogin, navigateTo, users }) => {
  const [formData, setFormData] = useState({ 
    username: '', 
    password: '', 
    role: 'hod' 
  });
  const [error, setError] = useState('');
  const [showPassword, setShowPassword] = useState(false);
    const [loading, setLoading] = useState(false);   // ✅ add this line

// --- Replace existing handleSubmit in LoginPage component ---
const handleSubmit = async (e) => {
  if (e && e.preventDefault) e.preventDefault();
  setError('');
  if (!formData.username || !formData.password) {
    setError('Please enter username and password');
    return;
  }
  setLoading(true);
  try {
    // prefer parent App's handleLogin if passed (keeps your app-level navigation)
    if (typeof handleLogin === 'function') {
      await handleLogin(formData.username, formData.password, formData.role);
      return;
    }
    // fallback: use api directly + save auth
    const res = await api.login(formData.username, formData.password, formData.role.toUpperCase());
    saveAuth(res.token, res.user);
    if (typeof navigateTo === 'function') {
      // navigateTo uses your app currentPage strings — keep same mapping if used
      const target = res.user.role === 'HOD' ? 'hodDashboard' : res.user.role === 'STAFF' ? 'staffDashboard' : 'studentDashboard';
      navigateTo(target);
    }
  } catch (err) {
    const msg = err?.error || err?.message || 'Login failed';
    setError(msg);
  } finally {
    setLoading(false);
  }
};


  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      handleSubmit();
    }
  };

  // Quick login buttons for testing
  const quickLogin = (username, password, role) => {
    setFormData({ username, password, role });
    setError('');
  };

  return (
    <div className="auth-container premium-bg">
      <div className="auth-card premium-card">
        <div className="auth-header">
          <h2 className="headline">Welcome back</h2>
          <p className="subtext">Sign in to continue to your dashboard</p>
        </div>
        
        <div className="auth-form">
          <div className="form-group">
            <label className="form-label">Role</label>
            <select 
              className="form-input"
              value={formData.role}
              onChange={(e) => setFormData(prev => ({ ...prev, role: e.target.value }))}

            >
              <option value="hod">HOD (Head of Department)</option>
              <option value="staff">Staff/Faculty</option>
              <option value="student">Student</option>
            </select>
          </div>

          <div className="form-group">
            <label className="form-label">Username</label>
            <input
              type="text"
              className="form-input"
              value={formData.username}
              onChange={(e) => setFormData(prev => ({ ...prev, username: e.target.value }))}

              onKeyPress={handleKeyPress}
              placeholder="Enter your username"
            />
            <FaUser className="input-icon" />
          </div>

          <div className="form-group">
            <label className="form-label">Password</label>
            <input
              type={showPassword ? 'text' : 'password'}
              className="form-input"
              value={formData.password}
              onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
              onKeyPress={handleKeyPress}
              placeholder="Enter your password"
            />
            <span 
              className="input-icon" 
              onClick={() => setShowPassword(!showPassword)}
              style={{ cursor: 'pointer' }}
            >
              {showPassword ? <FaEyeSlash /> : <FaEye />}
            </span>
          </div>

          {error && <div className="error-message">{error}</div>}

          <button onClick={handleSubmit} className="btn btn-primary premium-cta">
            <FaLock /> Sign in
          </button>
        </div>

        <div className="auth-links">
          {formData.role === 'hod' && (
            <button 
              className="auth-link" 
              onClick={() => navigateTo('signup')}
            >
              Create HOD account
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default LoginPage; 