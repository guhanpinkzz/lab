// components/SignupPage.js
import React, { useState } from 'react';
import { FaUser, FaEnvelope, FaLock, FaEye, FaEyeSlash, FaBuilding } from 'react-icons/fa'; // ✅ added FaBuilding
import api from '../utils/api';
import { getToken, getUser, saveAuth } from '../utils/auth';

const SignupPage = ({ handleSignup, navigateTo, users }) => {
  const [formData, setFormData] = useState({ 
    name: '', 
    email: '', 
    username: '', 
    password: '',
    confirmPassword: '',
    department: ''   // ✅ added department
  });
  const [error, setError] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);

    // Validation
    if (!formData.name || !formData.email || !formData.username || !formData.password || !formData.confirmPassword || !formData.department) {
      setError('Please fill in all fields');
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    if (formData.password.length < 6) {
      setError('Password must be at least 6 characters long');
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      setError('Please enter a valid email address');
      return;
    }

    try {
      const token = getToken(); 
      const { name, email, username, password, department } = formData;
      const res = await api.signupHOD({ name, email, username, password, department }, token); // ✅ send department

      if (res.token && res.user) {
        saveAuth(res.token, res.user);
        window.location.href = '/'; 
        return;
      }

      alert('HOD created. Please login.');
      if (typeof handleSignup === 'function') handleSignup();
    } catch (err) {
      setError(err?.error || err?.message || 'Signup failed');
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      handleSubmit();
    }
  };

  return (
    <div className="auth-container">
      <div className="auth-card">
        <div className="auth-header">
          <h1>HOD Registration</h1>
          <p>Create your Head of Department account</p>
        </div>
        
        <div>
          <div className="form-group">
            <label className="form-label">Full Name</label>
            <input
              type="text"
              className="form-input"
              value={formData.name}
              onChange={(e) => setFormData({...formData, name: e.target.value})}
              onKeyPress={handleKeyPress}
              placeholder="Enter your full name"
            />
            <FaUser className="input-icon" />
          </div>

          <div className="form-group">
            <label className="form-label">Email Address</label>
            <input
              type="email"
              className="form-input"
              value={formData.email}
              onChange={(e) => setFormData({...formData, email: e.target.value})}
              onKeyPress={handleKeyPress}
              placeholder="Enter your email"
            />
            <FaEnvelope className="input-icon" />
          </div>

          <div className="form-group">
            <label className="form-label">Username</label>
            <input
              type="text"
              className="form-input"
              value={formData.username}
              onChange={(e) => setFormData(prev => ({ ...prev, username: e.target.value }))}
              onKeyPress={handleKeyPress}
              placeholder="Choose a username"
            />
            <FaUser className="input-icon" />
          </div>

          {/* ✅ Department field */}
          <div className="form-group">
            <label className="form-label">Department</label>
            <input
              type="text"
              className="form-input"
              value={formData.department}
              onChange={(e) => setFormData(prev => ({ ...prev, department: e.target.value }))}
              onKeyPress={handleKeyPress}
              placeholder="Enter your department"
            />
            <FaBuilding className="input-icon" />
          </div>

          <div className="form-group">
            <label className="form-label">Password</label>
            <input
              type={showPassword ? 'text' : 'password'}
              className="form-input"
              value={formData.password}
              onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
              onKeyPress={handleKeyPress}
              placeholder="Create a password (min 6 characters)"
            />
            <span 
              className="input-icon" 
              onClick={() => setShowPassword(!showPassword)}
              style={{ cursor: 'pointer' }}
            >
              {showPassword ? <FaEyeSlash /> : <FaEye />}
            </span>
          </div>

          <div className="form-group">
            <label className="form-label">Confirm Password</label>
            <input
              type={showPassword ? 'text' : 'password'}
              className="form-input"
              value={formData.confirmPassword}
              onChange={(e) => setFormData({...formData, confirmPassword: e.target.value})}
              onKeyPress={handleKeyPress}
              placeholder="Confirm your password"
            />
            <FaLock className="input-icon" />
          </div>

          {error && <div className="error-message">{error}</div>}

          <button onClick={handleSubmit} className="btn btn-primary">
            <FaUser /> Create HOD Account
          </button>
        </div>

        <div className="auth-links">
          <button 
            className="auth-link"
            onClick={() => navigateTo('login')}
          >
            Already have an account? Login here
          </button>
        </div>

        {/* Information Box */}
        <div style={{ 
          marginTop: '20px', 
          padding: '15px', 
          background: '#e7f3ff', 
          borderRadius: '8px',
          fontSize: '12px',
          color: '#0066cc'
        }}>
          <strong>Note:</strong> Only HODs can create accounts. After registration, you can add staff and students to the system.
        </div>
      </div>
    </div>
  );
};

export default SignupPage;
