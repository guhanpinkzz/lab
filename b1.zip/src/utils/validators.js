import { z } from 'zod';

export const signupHodSchema = z.object({
  name: z.string().min(2),
  email: z.string().email(),
  username: z.string().min(3),
  password: z.string().min(6),
  department: z.string().min(2) 
});

export const loginSchema = z.object({
  username: z.string().min(1),
  password: z.string().min(1),
  role: z.enum(['HOD','STAFF','STUDENT'])
});

export const createUserSchema = z.object({
  name: z.string().min(2),
  email: z.string().email(),
  username: z.string().min(3),
  password: z.string().min(6),
  role: z.enum(['STAFF','STUDENT']),
  year: z.string().optional(),         // for students
  studentId: z.string().optional(),    // for students
  assignedLabs: z.array(z.string()).optional(), // for staff
  labs: z.array(z.string()).optional() // for students
});

export const changePasswordSchema = z.object({
  currentPassword: z.string().min(6),
  newPassword: z.string().min(6)
});

export const setPasswordSchema = z.object({
  newPassword: z.string().min(6)
});

export const labsByYearSchema = z.object({
  year: z.string().min(1),
  subjects: z.array(z.string()).min(0)
});

export const createAttendanceSchema = z.object({
  date: z.string().optional(), // ISO string, default now
  lab: z.string(),
  records: z.array(z.object({
    studentId: z.string(),
    status: z.enum(['PRESENT','ABSENT','NOT_ENROLLED_BUT_MARKED','DUPLICATE']).default('PRESENT')
  })).min(1)
});
