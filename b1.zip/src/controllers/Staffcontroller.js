// controllers/staffController.js - COMPLETE REWRITE FOR PROPER CONNECTIONS
import { prisma } from '../config/prisma.js';

// Helper to format year for frontend compatibility  
function formatYear(y) {
  if (!y) return 'Unknown';
  if (y === '1' || y === 1) return '1st';
  if (y === '2' || y === 2) return '2nd'; 
  if (y === '3' || y === 3) return '3rd';
  if (y === '4' || y === 4) return '4th';
  return `${y}`;
}

// Helper to normalize year values
function normalizeYear(year) {
  if (!year) return null;
  const y = year.toString().toLowerCase();
  if (y.includes('2nd') || y === '2') return '2';
  if (y.includes('3rd') || y === '3') return '3'; 
  if (y.includes('4th') || y === '4') return '4';
  return year;
}

// Get staff dashboard data with complete database integration
export async function getStaffDashboard(req, res) {
  try {
    const staffId = req.user.id;
    
    console.log(`🔍 Loading dashboard for staff ID: ${staffId}`);
    
    // Get staff user info
    const staff = await prisma.user.findUnique({
      where: { id: staffId },
      select: { 
        id: true, 
        name: true, 
        email: true, 
        username: true, 
        department: true,
        role: true
      }
    });

    if (!staff) {
      console.log('❌ Staff not found');
      return res.status(404).json({ error: 'Staff not found' });
    }

    if (staff.role !== 'STAFF') {
      console.log('❌ User is not a staff member');
      return res.status(403).json({ error: 'Access denied: User is not a staff member' });
    }

    // Get ALL labs this staff is assigned to with complete details
    const staffLabAssignments = await prisma.staffLabAssignment.findMany({
      where: { staffId },
      include: { 
        lab: {
          select: { 
            id: true, 
            name: true, 
            year: true 
          }
        }
      }
    });

    const assignedLabIds = staffLabAssignments.map(assignment => assignment.lab.id);
    const assignedLabNames = staffLabAssignments.map(assignment => assignment.lab.name);
    
    console.log(`📚 Staff assigned to ${assignedLabIds.length} labs:`, assignedLabNames);
    console.log(`📚 Lab IDs:`, assignedLabIds);

    if (assignedLabIds.length === 0) {
      console.log('📚 No labs assigned to this staff');
      return res.json({
        user_id: staff.id,
        user_name: staff.name,
        user_email: staff.email,
        user_department: staff.department,
        assigned_labs: [],
        total_students: 0,
        todays_attendance: 0,
        weekly_attendance: 0,
        pending_assignments: 0
      });
    }

    // Get ALL students in ANY of the staff's assigned labs
    const studentAssignments = await prisma.studentLabAssignment.findMany({
      where: { 
        labId: { in: assignedLabIds }
      },
      include: {
        student: {
          select: {
            id: true,
            name: true,
            studentId: true,
            year: true,
            email: true
          }
        },
        lab: {
          select: {
            id: true,
            name: true,
            year: true
          }
        }
      }
    });

    const totalStudents = studentAssignments.length;
    console.log(`👥 Found ${totalStudents} student assignments in staff's labs`);
    console.log(`👥 Student details:`, studentAssignments.map(sa => ({
      student: sa.student.name,
      studentId: sa.student.studentId,
      lab: sa.lab.name,
      year: sa.student.year
    })));

    // Get today's attendance count
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    const todayAttendance = await prisma.attendance.count({
      where: {
        labId: { in: assignedLabIds },
        date: { gte: today, lt: tomorrow }
      }
    });

    // Get this week's attendance for analytics
    const weekStart = new Date(today);
    weekStart.setDate(today.getDate() - today.getDay());
    
    const weeklyAttendance = await prisma.attendance.count({
      where: {
        labId: { in: assignedLabIds },
        date: { gte: weekStart }
      }
    });

    console.log(`📊 Dashboard stats: ${totalStudents} students, ${todayAttendance} today's attendance`);

    const dashboardData = {
      user_id: staff.id,
      user_name: staff.name,
      user_email: staff.email,
      user_department: staff.department,
      assigned_labs: assignedLabNames,
      total_students: totalStudents,
      todays_attendance: todayAttendance,
      weekly_attendance: weeklyAttendance,
      pending_assignments: 0
    };

    console.log('✅ Dashboard data prepared successfully:', dashboardData);
    res.json(dashboardData);
    
  } catch (e) {
    console.error('❌ Staff dashboard error:', e);
    return res.status(500).json({ error: e.message });
  }
}

// Get staff's assigned labs with complete details
export async function getStaffLabs(req, res) {
  try {
    const staffId = req.user.id;
    console.log(`🔍 Getting labs for staff ID: ${staffId}`);
    
    const staffLabAssignments = await prisma.staffLabAssignment.findMany({
      where: { staffId },
      include: { 
        lab: {
          include: {
            students: {
              include: {
                student: {
                  select: { 
                    id: true,
                    name: true, 
                    studentId: true,
                    year: true
                  }
                }
              }
            }
          }
        }
      }
    });

    const labs = staffLabAssignments.map(assignment => {
      const lab = assignment.lab;
      return {
        id: lab.id,
        name: lab.name,
        year: formatYear(lab.year),
        student_count: lab.students.length,
        students: lab.students.map(s => ({
          id: s.student.id,
          student_id: s.student.studentId,
          name: s.student.name,
          year: formatYear(s.student.year)
        })),
        assigned_date: assignment.createdAt || new Date().toISOString()
      };
    });

    console.log(`📚 Retrieved ${labs.length} labs for staff with students:`, 
      labs.map(l => `${l.name}: ${l.student_count} students`));
    
    res.json(labs);
    
  } catch (e) {
    console.error('❌ Get staff labs error:', e);
    return res.status(500).json({ error: e.message });
  }
}

// Get students in staff's assigned labs - COMPLETELY REWRITTEN
export async function getStaffStudents(req, res) {
  try {
    const staffId = req.user.id;
    const { labId } = req.params;
    
    console.log(`🔍 Getting students for staff ${staffId}${labId ? `, specific lab ${labId}` : ' (all labs)'}`);

    // First, get all labs this staff is assigned to
    const staffLabAssignments = await prisma.staffLabAssignment.findMany({
      where: { staffId },
      select: { labId: true, lab: { select: { name: true } } }
    });

    const assignedLabIds = staffLabAssignments.map(assignment => assignment.labId);
    
    console.log(`📚 Staff is assigned to lab IDs:`, assignedLabIds);
    
    if (assignedLabIds.length === 0) {
      console.log('📚 No labs assigned to this staff');
      return res.json([]);
    }

    // Build where clause for student lab assignments
    let whereClause = {
      labId: { in: assignedLabIds }
    };

    // If specific lab requested, ensure staff has access and filter by it
    if (labId) {
      const labIdNum = parseInt(labId);
      if (!assignedLabIds.includes(labIdNum)) {
        console.log(`❌ Staff ${staffId} not assigned to lab ${labIdNum}`);
        return res.status(403).json({ error: 'Access denied to this lab' });
      }
      whereClause.labId = labIdNum;
      console.log(`🔍 Filtering by specific lab ID: ${labIdNum}`);
    }

    // Get ALL student lab assignments that match our criteria
    const studentLabAssignments = await prisma.studentLabAssignment.findMany({
      where: whereClause,
      include: {
        student: {
          select: { 
            id: true, 
            name: true, 
            email: true, 
            year: true, 
            studentId: true,
            department: true
          }
        },
        lab: {
          select: { 
            id: true, 
            name: true, 
            year: true 
          }
        }
      }
    });

    console.log(`👥 Found ${studentLabAssignments.length} student-lab assignments`);

    // Transform data for frontend with proper year formatting
    const students = studentLabAssignments.map(assignment => {
      const student = assignment.student;
      const lab = assignment.lab;
      
      return {
        id: student.id,
        student_id: student.studentId || `STU${student.id}`,
        name: student.name,
        email: student.email,
        year: formatYear(student.year),
        raw_year: student.year, // Keep raw year for filtering
        department: student.department,
        assigned_lab: lab.name,
        lab_id: lab.id,
        lab_year: formatYear(lab.year),
        assigned_date: assignment.createdAt || new Date().toISOString()
      };
    });

    // Group students by year for better organization
    const studentsByYear = students.reduce((acc, student) => {
      const yearKey = student.year || 'Unknown';
      if (!acc[yearKey]) acc[yearKey] = [];
      acc[yearKey].push(student);
      return acc;
    }, {});

    console.log(`👥 Students by year:`, Object.entries(studentsByYear).map(([year, studs]) => 
      `${year}: ${studs.length} students`));

    console.log(`👥 Student details:`, students.map(s => 
      `${s.name} (${s.student_id}) - ${s.year} - ${s.assigned_lab}`));

    res.json(students);
    
  } catch (e) {
    console.error('❌ Get staff students error:', e);
    return res.status(500).json({ error: e.message });
  }
}

// Get attendance records for staff's labs with full details
export async function getStaffAttendance(req, res) {
  try {
    const staffId = req.user.id;
    const { labId } = req.params;

    console.log(`🔍 Getting attendance for staff ${staffId}${labId ? `, lab ${labId}` : ''}`);

    // Get staff's assigned labs
    const staffLabs = await prisma.staffLabAssignment.findMany({
      where: { staffId },
      select: { labId: true }
    });

    const assignedLabIds = staffLabs.map(sl => sl.labId);
    
    if (assignedLabIds.length === 0) {
      return res.json([]);
    }

    // Build where clause
    let where = {
      labId: { in: assignedLabIds }
    };

    // If specific lab requested, filter by it
    if (labId) {
      const labIdNum = parseInt(labId);
      if (assignedLabIds.includes(labIdNum)) {
        where.labId = labIdNum;
      } else {
        return res.status(403).json({ error: 'Access denied to this lab' });
      }
    }

    const attendanceRecords = await prisma.attendance.findMany({
      where,
      include: {
        student: {
          select: { 
            id: true,
            name: true, 
            studentId: true, 
            year: true,
            email: true
          }
        },
        lab: {
          select: { 
            id: true,
            name: true, 
            year: true 
          }
        }
      },
      orderBy: { date: 'desc' }
    });

    const formattedAttendance = attendanceRecords.map(record => ({
      id: record.id,
      student_id: record.student.studentId,
      student_name: record.student.name,
      student_year: formatYear(record.student.year),
      lab_name: record.lab.name,
      lab_id: record.lab.id,
      status: record.status.toLowerCase(),
      date: record.date.toISOString(),
      formatted_date: record.date.toLocaleDateString(),
      formatted_time: record.date.toLocaleTimeString()
    }));

    console.log(`📊 Retrieved ${formattedAttendance.length} attendance records`);
    res.json(formattedAttendance);
    
  } catch (e) {
    console.error('❌ Get staff attendance error:', e);
    return res.status(500).json({ error: e.message });
  }
}

// Mark attendance for single student with validation
export async function markAttendance(req, res) {
  try {
    const staffId = req.user.id;
    const { student_id, lab_id, status } = req.body;

    console.log(`📝 Marking attendance: Student ${student_id}, Lab ${lab_id}, Status ${status}`);

    if (!student_id || !lab_id || !status) {
      return res.status(400).json({ error: 'student_id, lab_id, and status are required' });
    }

    // Verify staff has access to this lab
    const staffLab = await prisma.staffLabAssignment.findFirst({
      where: { staffId, labId: parseInt(lab_id) },
      include: { lab: { select: { name: true } } }
    });

    if (!staffLab) {
      return res.status(403).json({ error: 'Access denied to this lab' });
    }

    // Find the student
    const student = await prisma.user.findFirst({
      where: { 
        OR: [
          { studentId: student_id },
          { id: isNaN(student_id) ? undefined : parseInt(student_id) }
        ]
      }
    });

    if (!student) {
      return res.status(404).json({ error: 'Student not found' });
    }

    // Check if attendance already exists today
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    const existingAttendance = await prisma.attendance.findFirst({
      where: {
        studentId: student.id,
        labId: parseInt(lab_id),
        date: { gte: today, lt: tomorrow }
      }
    });

    let attendanceRecord;
    if (existingAttendance) {
      attendanceRecord = await prisma.attendance.update({
        where: { id: existingAttendance.id },
        data: { status: status.toUpperCase() }
      });
    } else {
      attendanceRecord = await prisma.attendance.create({
        data: {
          studentId: student.id,
          labId: parseInt(lab_id),
          date: new Date(),
          status: status.toUpperCase()
        }
      });
    }

    console.log('✅ Attendance marked successfully');

    res.json({ 
      message: 'Attendance marked successfully',
      attendance: {
        id: attendanceRecord.id,
        student_id: student.studentId,
        student_name: student.name,
        lab_name: staffLab.lab.name,
        status: attendanceRecord.status.toLowerCase(),
        date: attendanceRecord.date.toISOString()
      }
    });
    
  } catch (e) {
    console.error('❌ Mark attendance error:', e);
    return res.status(500).json({ error: e.message });
  }
}

// Mark bulk attendance with enhanced validation
export async function markBulkAttendance(req, res) {
  try {
    const staffId = req.user.id;
    const { students, lab_id } = req.body;

    console.log(`📝 Bulk attendance for ${students?.length} students in lab ${lab_id}`);

    if (!students || !Array.isArray(students) || !lab_id) {
      return res.status(400).json({ error: 'students array and lab_id are required' });
    }

    // Verify staff has access to this lab
    const staffLab = await prisma.staffLabAssignment.findFirst({
      where: { staffId, labId: parseInt(lab_id) },
      include: { lab: { select: { name: true } } }
    });

    if (!staffLab) {
      return res.status(403).json({ error: 'Access denied to this lab' });
    }

    const results = [];
    const errors = [];

    for (const studentRecord of students) {
      try {
        const { student_id, status } = studentRecord;

        if (!student_id || !status) {
          errors.push(`Missing student_id or status for record: ${JSON.stringify(studentRecord)}`);
          continue;
        }

        // Find the student
        const student = await prisma.user.findFirst({
          where: { 
            OR: [
              { studentId: student_id },
              { id: isNaN(student_id) ? undefined : parseInt(student_id) }
            ]
          }
        });

        if (!student) {
          errors.push(`Student not found: ${student_id}`);
          continue;
        }

        // Check if attendance already exists today
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const tomorrow = new Date(today);
        tomorrow.setDate(tomorrow.getDate() + 1);

        const existingAttendance = await prisma.attendance.findFirst({
          where: {
            studentId: student.id,
            labId: parseInt(lab_id),
            date: { gte: today, lt: tomorrow }
          }
        });

        let attendanceRecord;
        if (existingAttendance) {
          attendanceRecord = await prisma.attendance.update({
            where: { id: existingAttendance.id },
            data: { status: status.toUpperCase() }
          });
        } else {
          attendanceRecord = await prisma.attendance.create({
            data: {
              studentId: student.id,
              labId: parseInt(lab_id),
              date: new Date(),
              status: status.toUpperCase()
            }
          });
        }

        results.push({ 
          student_id, 
          student_name: student.name,
          status: 'success', 
          attendance_id: attendanceRecord.id 
        });

      } catch (error) {
        errors.push(`Error for student ${studentRecord.student_id || 'unknown'}: ${error.message}`);
      }
    }

    console.log(`✅ Bulk attendance: ${results.length} success, ${errors.length} errors`);

    res.json({ 
      message: `Attendance marked for ${results.length} students in ${staffLab.lab.name}`,
      lab_name: staffLab.lab.name,
      results, 
      errors,
      summary: {
        total_attempted: students.length,
        successful: results.length,
        failed: errors.length
      }
    });
    
  } catch (e) {
    console.error('❌ Bulk attendance error:', e);
    return res.status(500).json({ error: e.message });
  }
}

// Update attendance record with validation
export async function updateAttendance(req, res) {
  try {
    const staffId = req.user.id;
    const attendanceId = parseInt(req.params.id);
    const { status } = req.body;

    console.log(`📝 Updating attendance record ${attendanceId} to ${status}`);

    if (!status) {
      return res.status(400).json({ error: 'Status is required' });
    }

    // Get attendance record with lab info
    const attendance = await prisma.attendance.findUnique({
      where: { id: attendanceId },
      include: { 
        lab: {
          include: {
            staff: {
              where: { staffId }
            }
          }
        },
        student: {
          select: { name: true, studentId: true }
        }
      }
    });

    if (!attendance) {
      return res.status(404).json({ error: 'Attendance record not found' });
    }

    if (attendance.lab.staff.length === 0) {
      return res.status(403).json({ error: 'Access denied to this attendance record' });
    }

    const updatedAttendance = await prisma.attendance.update({
      where: { id: attendanceId },
      data: { status: status.toUpperCase() }
    });

    console.log('✅ Attendance record updated successfully');

    res.json({ 
      message: 'Attendance updated successfully',
      attendance: {
        id: updatedAttendance.id,
        student_id: attendance.student.studentId,
        student_name: attendance.student.name,
        status: updatedAttendance.status.toLowerCase(),
        date: updatedAttendance.date.toISOString()
      }
    });
    
  } catch (e) {
    console.error('❌ Update attendance error:', e);
    return res.status(500).json({ error: e.message });
  }
}

// Delete attendance record with validation
export async function deleteAttendance(req, res) {
  try {
    const staffId = req.user.id;
    const attendanceId = parseInt(req.params.id);

    console.log(`🗑️  Deleting attendance record ${attendanceId}`);

    const attendance = await prisma.attendance.findUnique({
      where: { id: attendanceId },
      include: { 
        lab: {
          include: {
            staff: {
              where: { staffId }
            }
          }
        }
      }
    });

    if (!attendance) {
      return res.status(404).json({ error: 'Attendance record not found' });
    }

    if (attendance.lab.staff.length === 0) {
      return res.status(403).json({ error: 'Access denied to this attendance record' });
    }

    await prisma.attendance.delete({ where: { id: attendanceId } });

    console.log('✅ Attendance record deleted successfully');
    res.json({ message: 'Attendance record deleted successfully' });
    
  } catch (e) {
    console.error('❌ Delete attendance error:', e);
    return res.status(500).json({ error: e.message });
  }
}

// Get comprehensive staff statistics
export async function getStaffStats(req, res) {
  try {
    const staffId = req.user.id;
    
    console.log(`📊 Generating stats for staff ${staffId}`);
    
    // Get staff's assigned labs
    const staffLabs = await prisma.staffLabAssignment.findMany({
      where: { staffId },
      include: { lab: { select: { name: true } } }
    });

    const assignedLabIds = staffLabs.map(sl => sl.labId);
    
    if (assignedLabIds.length === 0) {
      return res.json({
        total_labs: 0,
        total_students: 0,
        todays_attendance: 0,
        this_week_attendance: 0,
        attendance_percentage: 0,
        recent_activity: []
      });
    }

    // Get total students in assigned labs
    const totalStudents = await prisma.studentLabAssignment.count({
      where: { labId: { in: assignedLabIds } }
    });

    // Get today's attendance
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    const todaysAttendance = await prisma.attendance.count({
      where: {
        labId: { in: assignedLabIds },
        date: { gte: today, lt: tomorrow }
      }
    });

    // Get this week's attendance
    const weekStart = new Date(today);
    weekStart.setDate(today.getDate() - today.getDay());
    
    const thisWeekAttendance = await prisma.attendance.count({
      where: {
        labId: { in: assignedLabIds },
        date: { gte: weekStart }
      }
    });

    // Calculate attendance percentage (this week vs expected)
    const daysInWeek = Math.ceil((today - weekStart) / (1000 * 60 * 60 * 24)) + 1;
    const expectedAttendance = totalStudents * daysInWeek;
    const attendancePercentage = expectedAttendance > 0 ? 
      Math.round((thisWeekAttendance / expectedAttendance) * 100) : 0;

    // Get recent attendance activity
    const recentActivity = await prisma.attendance.findMany({
      where: { labId: { in: assignedLabIds } },
      include: {
        student: { select: { name: true, studentId: true } },
        lab: { select: { name: true } }
      },
      orderBy: { date: 'desc' },
      take: 15
    });

    const formattedActivity = recentActivity.map(a => ({
      student_name: a.student.name,
      student_id: a.student.studentId,
      lab_name: a.lab.name,
      status: a.status.toLowerCase(),
      date: a.date.toISOString(),
      time_ago: getTimeAgo(a.date)
    }));

    const stats = {
      total_labs: assignedLabIds.length,
      total_students: totalStudents,
      todays_attendance: todaysAttendance,
      this_week_attendance: thisWeekAttendance,
      attendance_percentage: attendancePercentage,
      recent_activity: formattedActivity,
      summary: {
        labs_assigned: staffLabs.map(sl => sl.lab.name),
        daily_average: Math.round(thisWeekAttendance / Math.max(daysInWeek, 1)),
        completion_rate: totalStudents > 0 ? Math.round((todaysAttendance / totalStudents) * 100) : 0
      }
    };

    console.log(`📊 Generated stats: ${totalStudents} students, ${todaysAttendance} today, ${attendancePercentage}% weekly`);
    res.json(stats);

  } catch (e) {
    console.error('❌ Get staff stats error:', e);
    return res.status(500).json({ error: e.message });
  }
}

// Helper function to calculate time ago
function getTimeAgo(date) {
  const now = new Date();
  const diffMs = now - new Date(date);
  const diffMins = Math.floor(diffMs / (1000 * 60));
  const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

  if (diffMins < 60) return `${diffMins} minutes ago`;
  if (diffHours < 24) return `${diffHours} hours ago`;
  if (diffDays < 7) return `${diffDays} days ago`;
  return new Date(date).toLocaleDateString();
}