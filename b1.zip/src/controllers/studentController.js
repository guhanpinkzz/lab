// controllers/studentController.js
import { prisma } from '../config/prisma.js';

// Get student dashboard data - includes profile and statistics
export async function getStudentDashboard(req, res) {
  try {
    const studentId = req.user.id;
    
    // Get student user info
    const student = await prisma.user.findUnique({
      where: { id: studentId },
      select: { 
        id: true, 
        name: true, 
        email: true, 
        studentId: true, 
        year: true, 
        username: true, 
        department: true 
      }
    });

    if (!student) {
      return res.status(404).json({ error: 'Student not found' });
    }

    // Get student's lab assignments
    const studentLabs = await prisma.studentLabAssignment.findMany({
      where: { studentId },
      include: { lab: true }
    });

    const assignedLabNames = studentLabs.map(sl => sl.lab.name);
    const assignedLabIds = studentLabs.map(sl => sl.lab.id);

    // Get attendance records
    const attendanceRecords = await prisma.attendance.findMany({
      where: { studentId },
      include: { lab: true },
      orderBy: { date: 'desc' }
    });

    // Calculate statistics
    const totalClasses = attendanceRecords.length;
    const presentClasses = attendanceRecords.filter(a => a.status === 'PRESENT').length;
    const absentClasses = totalClasses - presentClasses;
    const overallPercentage = totalClasses > 0 ? Math.round((presentClasses / totalClasses) * 100) : 0;

    // Lab-wise statistics
    const labWiseStats = {};
    attendanceRecords.forEach(record => {
      const labName = record.lab.name;
      if (!labWiseStats[labName]) {
        labWiseStats[labName] = { total: 0, present: 0 };
      }
      labWiseStats[labName].total++;
      if (record.status === 'PRESENT') {
        labWiseStats[labName].present++;
      }
    });

    // Get this week's attendance
    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
    
    const thisWeekAttendance = await prisma.attendance.count({
      where: {
        studentId,
        date: { gte: oneWeekAgo }
      }
    });

    res.json({
      student_info: {
        id: student.id,
        name: student.name,
        email: student.email,
        student_id: student.studentId,
        year: student.year,
        department: student.department
      },
      assigned_labs: assignedLabNames,
      attendance_summary: {
        total_classes: totalClasses,
        present_classes: presentClasses,
        absent_classes: absentClasses,
        overall_percentage: overallPercentage,
        this_week_attendance: thisWeekAttendance
      },
      lab_wise_stats: labWiseStats
    });
  } catch (e) {
    console.error('Student dashboard error:', e);
    return res.status(500).json({ error: e.message });
  }
}

// Get student's attendance records (enhanced version)
export async function getStudentAttendance(req, res) {
  try {
    const studentId = req.user.id;
    const { lab_id } = req.query;

    // Build where clause
    let where = { studentId };
    
    // If specific lab requested, filter by it
    if (lab_id) {
      where.labId = parseInt(lab_id);
    }

    // Get attendance records
    const attendance = await prisma.attendance.findMany({
      where,
      include: { lab: true },
      orderBy: { date: 'desc' }
    });

    // Transform data to match frontend expectations
    const attendanceRecords = attendance.map(a => ({
      id: a.id,
      date: a.date.toISOString(),
      lab: a.lab.name,
      status: a.status.toLowerCase(),
      percentage: 85 // You can calculate this based on your logic
    }));

    res.json({ attendance: attendanceRecords });
  } catch (e) {
    console.error('Get student attendance error:', e);
    return res.status(500).json({ error: e.message });
  }
}

// Get student's assigned labs
export async function getStudentLabs(req, res) {
  try {
    const studentId = req.user.id;
    
    const studentLabAssignments = await prisma.studentLabAssignment.findMany({
      where: { studentId },
      include: { 
        lab: {
          include: {
            staffLabAssignments: {
              include: {
                staff: {
                  select: { name: true, email: true }
                }
              }
            }
          }
        }
      }
    });

    const labs = studentLabAssignments.map(sla => ({
      id: sla.lab.id,
      name: sla.lab.name,
      year: sla.lab.year || '',
      instructors: sla.lab.staffLabAssignments.map(sta => sta.staff),
      assigned_date: sla.createdAt || new Date().toISOString()
    }));

    res.json(labs);
  } catch (e) {
    console.error('Get student labs error:', e);
    return res.status(500).json({ error: e.message });
  }
}

// Get student notifications (if you have a notifications system)
export async function getStudentNotifications(req, res) {
  try {
    const studentId = req.user.id;
    
    // This assumes you have a notifications table
    // Adjust based on your actual notification system
    try {
      const notifications = await prisma.notification.findMany({
        where: { 
          OR: [
            { studentId },
            { userId: studentId },
            { targetRole: 'STUDENT' },
            { isGlobal: true }
          ]
        },
        orderBy: { createdAt: 'desc' },
        take: 10
      });

      const formattedNotifications = notifications.map(n => ({
        id: n.id,
        message: n.message,
        type: n.type || 'info',
        date: n.createdAt,
        read: n.read || false
      }));

      res.json(formattedNotifications);
    } catch (notificationError) {
      // If notifications table doesn't exist, return empty array
      console.log('Notifications table not found, returning empty array');
      res.json([]);
    }
  } catch (e) {
    console.error('Get student notifications error:', e);
    return res.status(500).json({ error: e.message });
  }
}

// Mark notification as read
export async function markNotificationRead(req, res) {
  try {
    const studentId = req.user.id;
    const notificationId = parseInt(req.params.id);

    try {
      const notification = await prisma.notification.findFirst({
        where: { 
          id: notificationId,
          OR: [
            { studentId },
            { userId: studentId }
          ]
        }
      });

      if (!notification) {
        return res.status(404).json({ error: 'Notification not found' });
      }

      await prisma.notification.update({
        where: { id: notificationId },
        data: { read: true }
      });

      res.json({ message: 'Notification marked as read' });
    } catch (notificationError) {
      // If notifications table doesn't exist
      res.status(404).json({ error: 'Notifications not available' });
    }
  } catch (e) {
    console.error('Mark notification read error:', e);
    return res.status(500).json({ error: e.message });
  }
}

// Get attendance statistics for charts/analytics
export async function getAttendanceStats(req, res) {
  try {
    const studentId = req.user.id;
    
    // Get attendance records
    const attendanceRecords = await prisma.attendance.findMany({
      where: { studentId },
      include: { lab: true }
    });

    // Overall stats
    const totalClasses = attendanceRecords.length;
    const presentClasses = attendanceRecords.filter(a => a.status === 'PRESENT').length;
    const absentClasses = totalClasses - presentClasses;

    // Lab-wise breakdown
    const labWiseData = {};
    attendanceRecords.forEach(record => {
      const labName = record.lab.name;
      if (!labWiseData[labName]) {
        labWiseData[labName] = { lab: labName, present: 0, total: 0 };
      }
      labWiseData[labName].total++;
      if (record.status === 'PRESENT') {
        labWiseData[labName].present++;
      }
    });

    // Calculate percentages
    Object.values(labWiseData).forEach(lab => {
      lab.absent = lab.total - lab.present;
      lab.percentage = lab.total > 0 ? Math.round((lab.present / lab.total) * 100) : 0;
    });

    // Monthly breakdown (last 6 months)
    const monthlyData = {};
    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

    attendanceRecords
      .filter(record => new Date(record.date) >= sixMonthsAgo)
      .forEach(record => {
        const monthKey = new Date(record.date).toISOString().substr(0, 7); // YYYY-MM
        if (!monthlyData[monthKey]) {
          monthlyData[monthKey] = { month: monthKey, present: 0, total: 0 };
        }
        monthlyData[monthKey].total++;
        if (record.status === 'PRESENT') {
          monthlyData[monthKey].present++;
        }
      });

    // Calculate monthly percentages
    Object.values(monthlyData).forEach(month => {
      month.percentage = month.total > 0 ? Math.round((month.present / month.total) * 100) : 0;
    });

    res.json({
      overall: {
        total: totalClasses,
        present: presentClasses,
        absent: absentClasses,
        percentage: totalClasses > 0 ? Math.round((presentClasses / totalClasses) * 100) : 0
      },
      lab_wise: Object.values(labWiseData),
      monthly: Object.values(monthlyData).sort((a, b) => a.month.localeCompare(b.month))
    });
  } catch (e) {
    console.error('Get attendance stats error:', e);
    return res.status(500).json({ error: e.message });
  }
}

// Update student profile
export async function updateStudentProfile(req, res) {
  try {
    const studentId = req.user.id;
    const { name, email } = req.body;

    const updatedStudent = await prisma.user.update({
      where: { id: studentId },
      data: { 
        ...(name && { name }),
        ...(email && { email })
      },
      select: { 
        id: true, 
        name: true, 
        email: true, 
        studentId: true, 
        year: true 
      }
    });

    res.json({ 
      message: 'Profile updated successfully',
      student: updatedStudent
    });
  } catch (e) {
    console.error('Update student profile error:', e);
    if (e.code === 'P2002') {
      return res.status(400).json({ error: 'Email already exists' });
    }
    return res.status(500).json({ error: e.message });
  }
}