// CORRECTED Lab Routes with Fixed Subject Management Endpoints
import { Router } from 'express';
import { auth, requireRole } from '../middleware/auth.js';
import {
  listLabs,
  createLab,
  updateLab,
  deleteLab,
  deleteLabByNameAndYear,
  assignStaffToLab,
  assignStudentsToLab,
  bulkAssignStudentsByYear,
  getYearSubjects,
  setYearSubjects,
  getLabAssignmentReport
} from '../controllers/labController.js';

const router = Router();

// Public routes (with auth)
router.use(auth(true));

// Get all labs (available to all authenticated users)
router.get('/', listLabs);

// Get year subjects
router.get('/years/:year', getYearSubjects);

// Get lab assignment report (available to all authenticated users)
router.get('/report', getLabAssignmentReport);

// HOD-only routes
router.use(requireRole('HOD'));

// **ENHANCED: Lab Subject Management Endpoints**
// Create new lab (for adding subjects)
router.post('/', createLab);

// Update existing lab
router.put('/:id', updateLab);

// **NEW: Delete lab by name and year (for removing subjects)**
router.delete('/by-name-year', deleteLabByNameAndYear);

// **ENHANCED: BULK ASSIGNMENT ENDPOINT**
router.post('/bulk-assign', bulkAssignStudentsByYear);

// Assign staff to labs
router.post('/assign-staff', assignStaffToLab);

// Assign students to lab (individual assignments)
router.post('/assign-students', assignStudentsToLab);

// Update year subjects
router.put('/years/:year', setYearSubjects);

// **ENHANCED: Delete lab with comprehensive cascade delete**
router.delete('/:id', deleteLab);

export default router;