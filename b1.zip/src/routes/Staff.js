// routes/staff.js - Updated with all staff endpoints
import { Router } from 'express';
import { auth, requireRole } from '../middleware/auth.js';
import { 
  getStaffDashboard,
  getStaffLabs,
  getStaffStudents,
  getStaffAttendance,
  markAttendance,
  markBulkAttendance,
  updateAttendance,
  deleteAttendance,
  getStaffStats
} from '../controllers/Staffcontroller.js';

const router = Router();

// Require authentication for all staff routes
router.use(auth(true));

// Require STAFF role for all routes
router.use(requireRole('STAFF'));

// Staff dashboard - get staff info and basic stats
router.get('/dashboard', getStaffDashboard);

// Staff statistics
router.get('/stats', getStaffStats);

// Staff labs - get assigned labs
router.get('/labs', getStaffLabs);

// Staff students - get students in assigned labs
router.get('/students', getStaffStudents);
router.get('/students/:labId', getStaffStudents); // Students in specific lab

// Staff attendance management
router.get('/attendance', getStaffAttendance);
router.get('/attendance/:labId', getStaffAttendance); // Attendance for specific lab
router.post('/attendance', markAttendance); // Mark single attendance
router.post('/bulk-attendance', markBulkAttendance); // Mark multiple attendance
router.put('/attendance/:id', updateAttendance); // Update attendance record
router.delete('/attendance/:id', deleteAttendance); // Delete attendance record

export default router;