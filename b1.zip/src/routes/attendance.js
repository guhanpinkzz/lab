import { Router } from 'express';
import { auth, requireRole } from '../middleware/auth.js';
import { createAttendance, getStudentAttendance, getSummary } from '../controllers/attendanceController.js';

const router = Router();

router.use(auth(true));

router.post('/', requireRole('STAFF','HOD'), createAttendance);
router.get('/student/:studentId', getStudentAttendance);
router.get('/summary', requireRole('HOD'), getSummary);

export default router;
